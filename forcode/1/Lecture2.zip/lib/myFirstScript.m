t = (0:10)';
y = sin(t)
plot(t,y)