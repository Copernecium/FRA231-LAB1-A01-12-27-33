function [out] = addFunction(int1,int2)
%ADDFUNCTION Summary of this function goes here
%   Detailed explanation goes here
out = int1 + int2;
end

